<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <h4 class="card-title">Default Datatable</h4>
                    <p class="card-title-desc">DataTables has most features enabled by
                        default, so all you need to do to use it with your own tables is to call
                        the construction function: <code>$().DataTable();</code>.
                    </p>

                    <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <thead>
                        <tr>
                            <th>SI</th>
                            <th>Image</th>
                            <th>Student ID</th>
                            <th>Student Name</th>
                            <th>Total</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td>
                                <img src="<?php echo e(asset($result->image)); ?>" alt="" height="50" width="50"/>
                            </td>
                            <td><?php echo e($result->id); ?></td>
                            <td><?php echo e($result->students); ?></td>
                            <td><?php echo e($result->achieve_number); ?></td>
                            <td>
                                <a href="<?php echo e(route('result.view', ['id'=>$result->id])); ?>" class="btn btn-success btn-sm">
                                    <i class="fa fa-book-open"></i>
                                </a>
                                <a href="<?php echo e(route('result.edit', ['id'=>$result->id])); ?>" class="btn btn-warning btn-sm">
                                    <i class="fa fa-edit"></i>
                                </a>
                                <a href="<?php echo e(route('result.delete', ['id'=>$result->id])); ?>" class="btn btn-danger btn-sm">
                                    <i class="fa fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                    </table>

                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sre\sis\resources\views/admin/result/manage.blade.php ENDPATH**/ ?>