<?php

namespace App\Http\Controllers;

use App\Models\Subject;
use Illuminate\Http\Request;

class ResultController extends Controller
{
    private $subjects ;
    public function index()
    {
        $this->subjects = Subject::all();
        return view('admin.result.add', ['subjects'=>$this->subjects]);
    }
}
